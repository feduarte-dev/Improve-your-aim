class MainMenu extends Phaser.Scene {
    constructor() {
        super({ key: 'MainMenu' });
    }

    preload() {
        // No assets to load for this simple example
    }

    create() {
        // Main page texts
        this.titleText = this.add.text(512, 200, 'Improve your aim', { fontSize: '48px', fill: '#ffffff' });
        this.titleText.setOrigin(0.5);

        this.clickHere = this.add.text(512, 400, 'Click here to start', { fontSize: '38px', fill: '#ffffff' });
        this.clickHere.setOrigin(0.5);

        // Initialize try counter
        if (!MainMenu.tryCounter) {
            MainMenu.tryCounter = 0;
        }

        // Add start game button logic
        this.input.once('pointerdown', this.startGame, this);
    }

    startGame() {
        MainMenu.tryCounter += 1;
        this.scene.start('GameScene', { tryNumber: MainMenu.tryCounter });
    }
}

class GameScene extends Phaser.Scene {
    constructor() {
        super({ key: 'GameScene' });
        // Initialize static leaderboard property if not already done
        if (!GameScene.leaderboardEntries) {
            GameScene.leaderboardEntries = [];
        }
    }

    preload() {
        // Load the PNG image
        this.load.image('dot', 'alien.png'); // Replace 'alien.png' with the actual path to your image

        // Load the audio file for background music
        this.load.audio('backgroundMusic', 'ufo.mp3'); // Replace with the actual path to your audio file

        // Load the audio file for the click sound
        this.load.audio('clickSound', 'laser-shot.mp3'); // Replace with the actual path to your audio file
    }

    create(data) {
        // Play the background music
        this.backgroundMusic = this.sound.add('backgroundMusic');
        this.backgroundMusic.play({ loop: true });

        // Add the click sound
        this.clickSound = this.sound.add('clickSound');

        // Create a sprite using the PNG image and scale it
        this.dot = this.add.sprite(512, 384, 'dot');
        this.dot.setScale(0.03);

        // Enable input on the dot
        this.dot.setInteractive();

        // Create a background for the text area
        this.add.rectangle(0, 0, 1024, 60, 0x333333).setOrigin(0, 0);

        // Create a background for the leaderboard area
        this.add.rectangle(850, 60, 174, 708, 0x444444).setOrigin(0, 0);

        // Initialize the score
        this.score = 0;

        // Create a text object to display the score
        this.scoreText = this.add.text(768, 16, 'Score: 0', { fontSize: '32px', fill: '#ffffff' });

        // Initialize the time counter
        this.timeLeft = 10;

        // Create a text object to display the time left
        this.timeText = this.add.text(16, 16, 'Time: 10', { fontSize: '32px', fill: '#ffffff' });

        // Create a text object for the timeout message (initially hidden)
        this.timeoutText = this.add.text(512, 384, 'Time Out', { fontSize: '64px', fill: '#ff0000' });
        this.timeoutText.setOrigin(0.5);
        this.timeoutText.setVisible(false);

        // Create the restart button (initially hidden)
        this.restartButton = this.add.text(512, 464, 'Restart', { fontSize: '32px', fill: '#ffffff' });
        this.restartButton.setOrigin(0.5);
        this.restartButton.setInteractive();
        this.restartButton.setVisible(false);

        // Add the restart button logic
        this.restartButton.on('pointerdown', () => {
            this.scene.restart({ tryNumber: data.tryNumber });
        });

        // Create leaderboard title
        this.leaderboardTitle = this.add.text(854, 80, 'Leaderboard', { fontSize: '24px', fill: '#ffffff' });

        // Display leaderboard entries (initially empty)
        this.leaderboardTexts = [];

        // Listen for the 'pointerdown' event on the dot
        this.dot.on('pointerdown', function (pointer) {
            if (this.timeLeft > 0) {
                // Play the click sound
                this.clickSound.play();

                // Move the dot to a random position on the canvas
                this.dot.x = Phaser.Math.Between(0, this.scale.width - 200);
                this.dot.y = Phaser.Math.Between(100, this.scale.height);

                // Increment the score
                this.score += 10;

                // Update the score text
                this.scoreText.setText('Score: ' + this.score);
            }
        }, this);

        // Listen for the 'pointerdown' event on the canvas
        this.input.on('pointerdown', function (pointer) {
            if (pointer.y > 60 && (pointer.x < this.dot.x - 5 || pointer.x > this.dot.x + 5 || pointer.y < this.dot.y - 5 || pointer.y > this.dot.y + 5)) {
                if (this.timeLeft > 0) {
                    // Decrement the score
                    this.score -= 5;

                    // Update the score text
                    this.scoreText.setText('Score: ' + this.score);
                }
            }
        }, this);

        // Create a timed event to decrement the score every second
        this.time.addEvent({
            delay: 1000,                // 1000 ms = 1 second
            callback: function () {
                if (this.timeLeft > 0) {
                    this.score -= 1;        // Decrement the score
                    this.scoreText.setText('Score: ' + this.score); // Update the score text

                    // Decrement the time left
                    this.timeLeft -= 1;
                    this.timeText.setText('Time: ' + this.timeLeft); // Update the time text

                    // Check if time has run out
                    if (this.timeLeft === 0) {
                        this.timeoutText.setVisible(true); // Show the timeout message
                        this.dot.setInteractive(false); // Disable dot interaction
                        this.updateLeaderboard(data.tryNumber, this.score); // Update the leaderboard
                        this.restartButton.setVisible(true); // Show the restart button
                    }
                }
            },
            callbackScope: this,
            loop: true
        });

        // Display the current leaderboard entries
        this.displayLeaderboard();
    }

    updateLeaderboard(tryNumber, score) {
        // Add the new entry to the leaderboard
        GameScene.leaderboardEntries.push({ tryNumber: tryNumber, score: score });

        // Sort the leaderboard entries by score in descending order
        GameScene.leaderboardEntries.sort((a, b) => b.score - a.score);

        // Display the updated leaderboard
        this.displayLeaderboard();
    }

    displayLeaderboard() {
        // Clear previous leaderboard texts
        this.leaderboardTexts.forEach(text => text.destroy());

        // Display updated leaderboard entries
        this.leaderboardTexts = [];
        for (let i = 0; i < GameScene.leaderboardEntries.length; i++) {
            let entry = GameScene.leaderboardEntries[i];
            let entryText = this.add.text(854, 120 + i * 40, `Try ${entry.tryNumber}: ${entry.score}`, { fontSize: '24px', fill: '#ffffff' });
            this.leaderboardTexts.push(entryText);
        }
    }

    update() {
        // No continuous updates needed for this example
    }
}

const config = {
    type: Phaser.AUTO,
    width: 1024,
    height: 768,
    backgroundColor: '#000000',
    scene: [MainMenu, GameScene]
};

const game = new Phaser.Game(config);
